function tirarDados() {
    let intervalo = setInterval(() => {
        let dado1 = Math.floor(Math.random() * 6) + 1;
        let dado2 = Math.floor(Math.random() * 6) + 1;
        document.getElementById("dado1").textContent = dado1;
        document.getElementById("dado2").textContent = dado2;
    }, 100);

    setTimeout(() => {
        clearInterval(intervalo);
    }, 5000);  // Detener después de 5 segundos
}
