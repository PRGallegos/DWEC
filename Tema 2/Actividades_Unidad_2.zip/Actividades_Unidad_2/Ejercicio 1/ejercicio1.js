document.getElementById("Enviar").addEventListener("click", function () {
    // Obtener el texto del input
    let texto = document.getElementById("parrafo").value;

    // Crear la nueva ventana
    let ventanaHija = window.open("", "", "width=400,height=300");

    // Crear un párrafo para mostrar el mensaje en la nueva ventana
    let p = document.createElement("p");
    p.innerHTML = texto;
    ventanaHija.document.body.appendChild(p);

    // Después de un breve retraso, agregar el tamaño de la ventana a la nueva ventana
    setTimeout(function () {
        let width = ventanaHija.outerWidth;
        let height = ventanaHija.outerHeight;
        let sizeInfo = document.createElement("p");
        sizeInfo.innerHTML = `Tamaño de la ventana: ${width}x${height}`;
        ventanaHija.document.body.appendChild(sizeInfo);
    }, 100);

    // Mostrar una alerta cuando la ventana hija se cierre
    ventanaHija.onbeforeunload = function () {
        alert("La nueva ventana ha sido cerrada.");
    };
});